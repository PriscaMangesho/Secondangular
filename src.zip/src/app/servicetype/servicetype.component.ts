import { Component, OnInit } from '@angular/core';
import {LoginUserService} from '../login-user.service';

@Component({
  selector: 'app-servicetype',
  templateUrl: './servicetype.component.html',
  styleUrls: ['./servicetype.component.css']
})
export class ServicetypeComponent implements OnInit {

    servicename: any;
    servicedesc: any;
  constructor(
      private service: LoginUserService
  ) { }

  ngOnInit() {
  }

    servicetypesubmit() {
        this.service.serviceTuma(this.servicename, this.servicedesc).subscribe(res => {
            // console.log(res);
        });
    }

}
