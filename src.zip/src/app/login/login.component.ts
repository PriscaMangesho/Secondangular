import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {FormBuilder, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {LoginUserService} from '../login-user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    username: string;
    password: string;

    // loginForm: FormGroup;
  constructor(
      private userservice: LoginUserService,
      private router: Router,
  ) { }

  ngOnInit() {
     // this.LoginFormData();
  }


//     LoginFormData() {
//     this.loginForm = this.fb.group({
//     username: ['', [Validators.required, Validators.email]],
//     password: ['', [Validators.required]],
// });
// }


  signin() {
    this.userservice.login(this.username, this.password).subscribe((res: any) => {
        // console.log(res['status']);
        if (res['status'] == 200) {
         this.router.navigate(['/home']);
        } else {
            console.log(res['status']);
        }



      });
  }
}
