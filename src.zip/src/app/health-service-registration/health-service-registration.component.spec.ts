import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthServiceRegistrationComponent } from './health-service-registration.component';

describe('HealthServiceRegistrationComponent', () => {
  let component: HealthServiceRegistrationComponent;
  let fixture: ComponentFixture<HealthServiceRegistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HealthServiceRegistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthServiceRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
