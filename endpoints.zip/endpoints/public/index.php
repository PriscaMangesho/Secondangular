<?php
/**
 * Created by PhpStorm.
 * User: Hebron
 * Date: 2/13/2019
 * Time: 7:29 AM
 */


header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET,PUT,POST,DELETE');
header('Access-Control-Max-Age:1000');
header('Access-Control-Allow-Headers: Origin,Content-Type,X-Auth-Token,Authorization');
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

require "../vendor/autoload.php";

$config = [
    'settings' => [
        'addContentLengthHeader' => false,
        'displayErrorDetails' => true,
        'db' => [
            'host' => "localhost",
            'username' => "root",
            'password' => "",
            'db_name' => "healthDb"
        ]
    ]
];


$app = new \Slim\App($config);

require 'dependencies.php';

$app->get('/login/{username}/{password}', function($request,$response,$args){
    $username = $args['username'];
    $password = md5($args['password']);

    $sql = "SELECT * FROM `tbl_user` WHERE `username`='".$username."' AND `password`='".$password."'";
    $t = $this->db->prepare($sql);
    $t->execute();
    $result = array();
    if ($t->rowCount()>0){
        $row = $t->fetch();
        $result['status'] = '200';
        $result['data'] = [
            'firstname' => $row['firstname'],
            'lastname' => $row['lastname'],
        ];

//        return $response->withJson($result);
    }else{
        $result['status'] = '400';

    }
    return $response
    ->withStatus(200)
        ->withHeader("Content-Type", "application/json")
        ->withHeader("Access-Control-Allow-Origin", "*")
        ->withHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        ->withHeader("Access-Control-Allow-Headers", "Content-Type, Depth, User-Agent, X-File-Size,X-Requested-With, If-Modified-Since,X-File-Name, Cache-Control, x-hash-key, x-req-timestamp, user-language-pref, Content_Language")
        ->withJson($result);
});





$app->post('/register_facility', function (Request $req,  Response $res, $args = []) {
    $facility_name = $req->getParsedBody()['name'];
    $facility_description = $req->getParsedBody()['description'];
    $quel= "INSERT INTO `tbl_facility`(`id`, `Name`, `Description`) VALUES (NULL,'".$facility_name."','".$facility_description ."')";
    $jah= $this->db->prepare($quel);
    $jah->execute();
    if ($jah->rowCount()>0)
    {
        $result=array(
            'status'=>200,
            'data'=>'success'


        );
    }
    else {
        $result=array(
            'status'=> 400,
            'data'=>'data not iserted'
        );
    }
    return $res->withJson($result);
});

$app->post('/register_servicetype', function (Request $req,  Response $res, $args = []) {
    $facility_name = $req->getParsedBody()['name'];
    $facility_description = $req->getParsedBody()['description'];
    $quel= "INSERT INTO `tbl_facilit_service_type`(`id`, `Name`, `Description`) VALUES (NULL,'".$facility_name."','".$facility_description ."')";
    $jah= $this->db->prepare($quel);
    $jah->execute();
    if ($jah->rowCount()>0)
    {
        $result=array(
            'status'=>200,
            'data'=>'success'


        );
    }
    else {
        $result=array(
            'status'=> 400,
            'data'=>'data not iserted'
        );
    }
    return $res->withJson($result);
});

$app->post('/register_service', function (Request $req,  Response $res, $args = []) {
    $service_name = $req->getParsedBody()['name'];
    $facility_id = $req->getParsedBody()['facility_id'];
    $service_id = $req->getParsedBody()['service_id'];
    $quel= "INSERT INTO `tbl__service`(`id`, `name`, `facility_id`, `sercice_type_id`) VALUES (NULL,'".$service_name."','".$facility_id."','".$service_id."')";
    $jah= $this->db->prepare($quel);
    $jah->execute();
    if ($jah->rowCount()>0)
    {
        $result=array(
            'status'=>200,
            'data'=>'success'
        );
    }
    else {
        $result=array(
            'status'=> 400,
            'data'=>'data not iserted'
        );
    }
    return $res->withJson($result);
});

$app->get('/view', function (Request $req,  Response $res, $args = []) {
    $sql ="SELECT `tbl__service`.`id`,`tbl__service`.`name`,`tbl_facilit_service_type`.`Name` as service_type_name,`tbl_facility`.`Name` as facility_name FROM `tbl_facilit_service_type`,`tbl__service`,`tbl_facility` WHERE `tbl__service`.`facility_id`=`tbl_facility`.`id` AND `tbl__service`.`sercice_type_id`=`tbl_facilit_service_type`.`id`";
    $jah= $this->db->prepare($sql);
    $jah->execute();
    $result= array();
    if ($jah->rowCount()>0){
        $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
    }
    else {
        return $res->withJson($result);
    }

});



$app->get('/facility', function (Request $req,  Response $res, $args = []) {
    $sql ="SELECT * FROM `tbl_facility`";
    $jah= $this->db->prepare($sql);
    $jah->execute();
    $result= array();
    if ($jah->rowCount()>0){
        $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
    }
    else {
        return $res->withJson($result);
    }

});



$app->get('/viewservice', function (Request $req,  Response $res, $args = []) {
    $sql ="SELECT * FROM `tbl_facilit_service_type`";
    $jah= $this->db->prepare($sql);
    $jah->execute();
    $result= array();
    if ($jah->rowCount()>0){
        $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
    }
    else {
        return $res->withJson($result);
    }

});


$app->run();